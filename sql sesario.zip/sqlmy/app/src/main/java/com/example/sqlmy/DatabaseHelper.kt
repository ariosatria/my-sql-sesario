package com.example.sqlmy


import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper



class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        const val DATABASE_NAME = "mydb.db"
        const val DATABASE_VERSION = 1

        const val TABLE_NAME = "mytable"
        const val ID = "_id"
        const val NAME = "name"
        const val AGE = "age"
        const val GENDER = "gender"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val CREATE_TABLE = "CREATE TABLE ${TABLE_NAME} (" +
                "${ID} INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "${NAME} TEXT, " +
                "${AGE} INTEGER, " +
                "${GENDER} TEXT" +
                ");"
        db?.execSQL(CREATE_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        val DROP_TABLE = "DROP TABLE IF EXISTS ${TABLE_NAME};"
        db?.execSQL(DROP_TABLE)
        onCreate(db)
    }
}